// Zero-dependency backend: serves the site and stores app state in data.json.  Run: node server.js
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=__dirname,DB=path.join(ROOT,'data.json'),PORT=process.env.PORT||3000;
const MIME={'.html':'text/html','.css':'text/css','.js':'application/javascript','.json':'application/json','.md':'text/plain'};
http.createServer(function(req,res){
 const url=decodeURIComponent(req.url.split('?')[0]);
 if(url==='/api/state'){
  if(req.method==='GET')return fs.readFile(DB,'utf8',function(e,t){res.writeHead(200,{'Content-Type':'application/json'});res.end(e?'{}':t);});
  if(req.method==='PUT'){let b='';req.on('data',function(c){b+=c;if(b.length>5e6)req.destroy();});
   req.on('end',function(){try{JSON.parse(b);}catch(e){res.writeHead(400);return res.end();}
    fs.writeFile(DB,b,function(){res.writeHead(200,{'Content-Type':'application/json'});res.end('{"ok":true}');});});return;}
  res.writeHead(405);return res.end();}
 const f=path.normalize(path.join(ROOT,url==='/'?'index.html':url)),n=path.basename(f);
 if(!f.startsWith(ROOT)||n==='data.json'||n==='server.js'){res.writeHead(404);return res.end('Not found');}
 fs.readFile(f,function(e,d){if(e){res.writeHead(404);return res.end('Not found');}
  res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});res.end(d);});
}).listen(PORT,function(){console.log('Delivery Route Optimizer running at http://localhost:'+PORT);});
