
## Two ways to run

1. **Go Live (VS Code Live Server)** - frontend only; data is kept in browser `localStorage`.
2. **With backend** - run `node server.js` (or `npm start`) in the project folder and open http://localhost:3000 in Edge.
   Data is then also saved to `data.json` on disk and survives clearing the browser. No `npm install` needed.
