function renderAssignment(a) {
  var body = document.getElementById("assignmentRows");
  var box = document.getElementById("unassigned");
  if (!a) {
    body.innerHTML = '<tr><td colspan="5">Click "Run Assignment" to assign deliveries.</td></tr>';
    box.className = "alert info"; box.removeAttribute("style");
    box.textContent = "Run assignment to check.";
    return;
  }
  var del = getDeliveries();
  function name(id) {
    var d = del.filter(function (x) { return x.id === id; })[0];
    return d ? esc(id) + " (" + esc(d.customer) + ", " + esc(d.demand) + ")" : esc(id);
  }
  if (!a.vehicles.length) {
    body.innerHTML = '<tr><td colspan="5">No available vehicles. Add or enable a vehicle first.</td></tr>';
  } else {
    body.innerHTML = a.vehicles.map(function (s) {
      return "<tr><td>" + esc(s.vehicleId) + "</td><td>" + s.capacity + "</td><td>" + s.assigned + "</td><td>" + s.remaining +
        "</td><td>" + (s.deliveries.length ? s.deliveries.map(name).join(", ") : "-") + "</td></tr>";
    }).join("");
  }
  if (a.unassigned.length) {
    box.className = "alert";
    box.setAttribute("style", "background:#ffedd5;color:#c2410c");
    box.innerHTML = "These deliveries do not fit in any available vehicle: " + a.unassigned.map(name).join(", ");
  } else {
    box.className = "alert info"; box.removeAttribute("style");
    box.textContent = "All active deliveries are assigned.";
  }
}

function assignVehicles() { renderAssignment(runAssignment()); }

renderAssignment(getAssignment());
