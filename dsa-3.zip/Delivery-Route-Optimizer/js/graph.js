/* Graph algorithms: Dijkstra, greedy sequence, route metrics */
function edgeKey(a, b) { return [a, b].sort().join("|"); }

var REAL_KM = {};
GRAPH_EDGES.forEach(function (e) { REAL_KM[edgeKey(e[0], e[1])] = e[2]; });

function buildGraph(opts) {
  opts = opts || {};
  var t = opts.traffic || 1, pen = opts.penalties || {};
  var g = {};
  GRAPH_NODES.forEach(function (n) { g[n] = []; });
  GRAPH_EDGES.forEach(function (e) {
    var w = e[2] * t * (pen[edgeKey(e[0], e[1])] || 1);
    g[e[0]].push({ to: e[1], w: w });
    g[e[1]].push({ to: e[0], w: w });
  });
  return g;
}

function dijkstra(g, src) {
  var dist = {}, prev = {}, done = {};
  GRAPH_NODES.forEach(function (n) { dist[n] = Infinity; });
  dist[src] = 0;
  for (var i = 0; i < GRAPH_NODES.length; i++) {
    var u = null;
    GRAPH_NODES.forEach(function (n) { if (!done[n] && (u === null || dist[n] < dist[u])) u = n; });
    if (u === null || dist[u] === Infinity) break;
    done[u] = true;
    g[u].forEach(function (e) {
      if (dist[u] + e.w < dist[e.to]) { dist[e.to] = dist[u] + e.w; prev[e.to] = u; }
    });
  }
  return { dist: dist, prev: prev };
}

function pathTo(res, src, dst) {
  if (res.dist[dst] === Infinity) return null;
  var path = [dst], c = dst;
  while (c !== src) { c = res.prev[c]; if (c === undefined) return null; path.unshift(c); }
  return path;
}

function pathKm(path) {
  var km = 0;
  for (var i = 0; i < path.length - 1; i++) km += REAL_KM[edgeKey(path[i], path[i + 1])] || 0;
  return km;
}

/* Compare two strategies for visiting a set of locations from the warehouse */
function computeRoute(locs, opts) {
  var W = "Warehouse";
  var g = buildGraph({ penalties: (opts && opts.penalties) || {} });
  var cache = {};
  function sp(n) { return cache[n] || (cache[n] = dijkstra(g, n)); }
  var stops = [];
  locs.forEach(function (l) { if (g[l] && l !== W && stops.indexOf(l) < 0) stops.push(l); });

  // Strategy 1: Dijkstra shortest path, separate round trip per stop
  var dPath = [W];
  stops.forEach(function (s) {
    var p = pathTo(sp(W), W, s);
    dPath = dPath.concat(p.slice(1)).concat(p.slice().reverse().slice(1));
  });

  // Strategy 2: greedy nearest-neighbour sequence using Dijkstra distances
  var cur = W, remaining = stops.slice(), order = [], gPath = [W];
  while (remaining.length) {
    var from = sp(cur);
    remaining.sort(function (a, b) { return from.dist[a] - from.dist[b]; });
    var nxt = remaining.shift();
    order.push(nxt);
    gPath = gPath.concat(pathTo(from, cur, nxt).slice(1));
    cur = nxt;
  }
  if (stops.length) gPath = gPath.concat(pathTo(sp(cur), cur, W).slice(1));

  var dKm = pathKm(dPath), gKm = pathKm(gPath);
  var greedyWins = gKm <= dKm;
  return {
    order: order,
    dijkstra: { path: dPath, km: dKm },
    greedy: { path: gPath, km: gKm },
    best: greedyWins ? "Greedy" : "Dijkstra",
    path: greedyWins ? gPath : dPath,
    km: greedyWins ? gKm : dKm
  };
}

/* Build + save optimized routes for every vehicle in the current assignment */
function optimizeRoutes() {
  var s = getSettings();
  var asg = getAssignment() || runAssignment();
  var deliveries = getDeliveries(), vehicles = getVehicles();
  var routes = [];
  asg.vehicles.forEach(function (slot) {
    if (!slot.deliveries.length) return;
    var v = vehicles.filter(function (x) { return x.id === slot.vehicleId; })[0];
    if (!v) return;
    var locs = [];
    slot.deliveries.forEach(function (id) {
      var d = deliveries.filter(function (x) { return x.id === id; })[0];
      if (d) locs.push(d.location);
    });
    var r = computeRoute(locs, { penalties: s.penalties });
    var fuel = r.km / v.efficiency;
    routes.push({
      vehicleId: v.id, packages: slot.assigned, capacity: slot.capacity,
      deliveries: slot.deliveries, stops: r.order, path: r.path, km: r.km,
      time: r.km / s.speed * 60 * s.traffic, fuel: fuel, cost: fuel * s.fuelPrice,
      dijkstraKm: r.dijkstra.km, greedyKm: r.greedy.km, algorithm: r.best
    });
  });
  save(KEYS.routes, routes);
  return routes;
}
