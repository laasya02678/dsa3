var ROUTE_COLORS = ["#2563eb", "#15803d", "#c2410c", "#7c3aed", "#db2777"];

function drawMap() {
  var routes = getRoutes(), pen = getSettings().penalties || {};
  var svg = '<svg viewBox="0 0 900 560" xmlns="http://www.w3.org/2000/svg">';

  GRAPH_EDGES.forEach(function (e) {
    var a = NODE_POS[e[0]], b = NODE_POS[e[1]], jam = pen[edgeKey(e[0], e[1])];
    svg += '<line x1="' + a[0] + '" y1="' + a[1] + '" x2="' + b[0] + '" y2="' + b[1] + '" stroke="' + (jam ? "#f97316" : "#cbd5e1") +
      '" stroke-width="' + (jam ? 4 : 3) + '"' + (jam ? ' stroke-dasharray="8 5"' : "") + "/>";
    svg += '<text x="' + ((a[0] + b[0]) / 2) + '" y="' + ((a[1] + b[1]) / 2 - 6) + '" font-size="12" fill="#64748b" text-anchor="middle">' + e[2] + " km</text>";
  });

  routes.forEach(function (r, i) {
    var off = i * 4 - (routes.length - 1) * 2, col = ROUTE_COLORS[i % ROUTE_COLORS.length];
    for (var k = 0; k < r.path.length - 1; k++) {
      var a = NODE_POS[r.path[k]], b = NODE_POS[r.path[k + 1]];
      var dx = b[0] - a[0], dy = b[1] - a[1], len = Math.sqrt(dx * dx + dy * dy) || 1;
      var ox = -dy / len * off, oy = dx / len * off;
      svg += '<line x1="' + (a[0] + ox) + '" y1="' + (a[1] + oy) + '" x2="' + (b[0] + ox) + '" y2="' + (b[1] + oy) +
        '" stroke="' + col + '" stroke-width="4" stroke-linecap="round" opacity="0.85"/>';
    }
  });

  var del = getDeliveries().filter(function (d) { return d.status !== "Delivered"; });
  GRAPH_NODES.forEach(function (n) {
    var p = NODE_POS[n], isW = n === "Warehouse";
    var pk = del.filter(function (d) { return d.location === n; }).reduce(function (a, d) { return a + d.demand; }, 0);
    svg += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="' + (isW ? 20 : 15) + '" fill="' + (isW ? "#15803d" : "#172b4d") + '" stroke="#fff" stroke-width="3"/>';
    svg += '<text x="' + p[0] + '" y="' + (p[1] + 5) + '" font-size="14" text-anchor="middle" fill="#fff">' + (isW ? "W" : "•") + "</text>";
    svg += '<text x="' + p[0] + '" y="' + (p[1] + 38) + '" font-size="14" font-weight="700" text-anchor="middle" fill="#172033">' + esc(n) + "</text>";
    if (pk) svg += '<text x="' + p[0] + '" y="' + (p[1] + 54) + '" font-size="12" text-anchor="middle" fill="#64748b">' + pk + " pkgs</text>";
  });
  document.getElementById("mapCanvas").innerHTML = svg + "</svg>";

  var box = document.getElementById("mapRoute");
  if (!routes.length) {
    box.innerHTML = '<div class="alert info">No route calculated yet. Click "Re-route" to assign vehicles and calculate routes.</div>';
    return;
  }
  var note = Object.keys(pen).length
    ? '<p class="alert" style="background:#ffedd5;color:#c2410c">Traffic jam on: ' + Object.keys(pen).map(function (k) { return esc(k.replace("|", " – ")); }).join(", ") + " (dashed orange road). Routes avoid it where possible.</p>" : "";
  box.innerHTML = note + routes.map(function (r, i) {
    return '<p><span style="display:inline-block;width:14px;height:14px;border-radius:3px;background:' + ROUTE_COLORS[i % ROUTE_COLORS.length] +
      ';margin-right:8px;vertical-align:middle"></span><strong>' + esc(r.vehicleId) + "</strong>: " + r.path.map(esc).join(" → ") +
      " — " + fmtKm(r.km) + ", " + fmtMin(r.time) + "</p>";
  }).join("");
}

function reroute() {
  var s = getSettings();
  var current = getRoutes();
  // simulate a traffic jam on a random road of the current route, then recalculate
  var used = [];
  current.forEach(function (r) {
    for (var k = 0; k < r.path.length - 1; k++) {
      var key = edgeKey(r.path[k], r.path[k + 1]);
      if (used.indexOf(key) < 0) used.push(key);
    }
  });
  s.penalties = {};
  if (used.length) s.penalties[used[Math.floor(Math.random() * used.length)]] = 3;
  setSettings(s);
  var routes = optimizeRoutes();
  if (!routes.length) {
    s.penalties = {}; setSettings(s);
    alert("Nothing to route. Add active deliveries and available vehicles first.");
  }
  drawMap();
}

drawMap();
