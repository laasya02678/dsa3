(function () {
  var del = getDeliveries(), veh = getVehicles(), routes = getRoutes();
  function sum(k) { return routes.reduce(function (a, r) { return a + r[k]; }, 0); }
  function cnt(s) { return del.filter(function (d) { return d.status === s; }).length; }
  document.getElementById("statDeliveries").textContent = del.length;
  document.getElementById("statVehicles").textContent = veh.filter(function (v) { return v.availability === "Available"; }).length;
  document.getElementById("statDistance").textContent = fmtKm(sum("km"));
  document.getElementById("statCost").textContent = fmtMoney(sum("cost"));
  document.getElementById("statTime").textContent = fmtMin(sum("time"));
  document.getElementById("statFuel").textContent = fmtL(sum("fuel"));
  document.getElementById("dashPending").textContent = cnt("Pending");
  document.getElementById("dashTransit").textContent = cnt("In Transit");
  document.getElementById("dashDelivered").textContent = cnt("Delivered");
})();
