function renderVehicles() {
  var list = getVehicles();
  var body = document.getElementById("vehicleRows");
  if (!list.length) { body.innerHTML = '<tr><td colspan="5">No vehicles yet. Add one above.</td></tr>'; return; }
  body.innerHTML = list.map(function (v) {
    var ok = v.availability === "Available";
    return "<tr><td>" + esc(v.id) + "</td><td>" + esc(v.capacity) + " packages</td><td>" + esc(v.efficiency) +
      " km/L</td><td>" + '<span class="badge ' + (ok ? "success" : "warning") + '">' + esc(v.availability) + "</span></td><td>" +
      '<button class="btn secondary" onclick="toggleVehicle(\'' + esc(v.id) + '\')">' + (ok ? "Make Unavailable" : "Make Available") + "</button> " +
      '<button class="btn danger" onclick="deleteVehicle(\'' + esc(v.id) + '\')">Delete</button></td></tr>';
  }).join("");
}

function toggleVehicle(id) {
  var list = getVehicles();
  list.forEach(function (v) { if (v.id === id) v.availability = v.availability === "Available" ? "Unavailable" : "Available"; });
  setVehicles(list);
  renderVehicles();
}

function deleteVehicle(id) {
  if (!confirm("Delete vehicle " + id + "?")) return;
  setVehicles(getVehicles().filter(function (v) { return v.id !== id; }));
  renderVehicles();
}

document.getElementById("vehicleForm").addEventListener("submit", function (e) {
  e.preventDefault();
  var id = document.getElementById("vehicleId").value.trim().toUpperCase();
  var cap = parseInt(document.getElementById("capacity").value, 10);
  var eff = parseFloat(document.getElementById("efficiency").value);
  var av = document.getElementById("availability").value;
  if (!/^[A-Z0-9_-]+$/.test(id)) { alert("Vehicle ID may only contain letters, numbers, - and _."); return; }
  if (!cap || cap < 1) { alert("Capacity must be at least 1."); return; }
  if (!eff || eff <= 0) { alert("Fuel efficiency must be greater than 0."); return; }
  var list = getVehicles();
  if (list.some(function (v) { return v.id === id; })) { alert("Vehicle " + id + " already exists."); return; }
  list.push({ id: id, capacity: cap, efficiency: eff, availability: av });
  setVehicles(list);
  this.reset();
  renderVehicles();
});

renderVehicles();
