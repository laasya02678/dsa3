function renderOptimization(routes) {
  var cmp = document.getElementById("algorithmComparison");
  var out = document.getElementById("optimizedRoutes");
  if (!routes.length) {
    cmp.textContent = "Run optimization.";
    out.innerHTML = '<div class="alert info">No routes yet. Make sure there are active deliveries and available vehicles, then click "Optimize Routes".</div>';
    return;
  }
  var dj = routes.reduce(function (a, r) { return a + r.dijkstraKm; }, 0);
  var gr = routes.reduce(function (a, r) { return a + r.greedyKm; }, 0);
  var best = Math.min(dj, gr);
  var saving = Math.max(dj, gr) > 0 ? (Math.max(dj, gr) - best) / Math.max(dj, gr) * 100 : 0;
  cmp.innerHTML =
    '<div class="metric-grid"><div class="metric">Dijkstra (separate trips)<strong>' + fmtKm(dj) + '</strong></div>' +
    '<div class="metric">Greedy sequence<strong>' + fmtKm(gr) + '</strong></div>' +
    '<div class="metric">Distance saved<strong>' + saving.toFixed(1) + '%</strong></div></div>' +
    '<p class="hint">The shorter of the two is used for each vehicle.</p>';
  out.innerHTML = '<div class="table-wrap"><table><thead><tr><th>Vehicle</th><th>Packages</th><th>Route</th><th>Distance</th><th>Time</th><th>Fuel</th><th>Cost</th><th>Method</th></tr></thead><tbody>' +
    routes.map(function (r) {
      return "<tr><td>" + esc(r.vehicleId) + "</td><td>" + r.packages + "/" + r.capacity + "</td><td>" + r.path.map(esc).join(" → ") +
        "</td><td>" + fmtKm(r.km) + "</td><td>" + fmtMin(r.time) + "</td><td>" + fmtL(r.fuel) + "</td><td>" + fmtMoney(r.cost) +
        '</td><td><span class="badge success">' + esc(r.algorithm) + "</span></td></tr>";
    }).join("") + "</tbody></table></div>";
}

function optimizeAll() {
  var traffic = parseFloat(document.getElementById("optTraffic").value) || 1;
  var speed = parseFloat(document.getElementById("speed").value);
  var fuelPrice = parseFloat(document.getElementById("fuelPrice").value);
  if (!(speed >= 5 && speed <= 120)) { alert("Average speed must be between 5 and 120 km/h."); return; }
  if (!(fuelPrice > 0)) { alert("Fuel price must be greater than 0."); return; }
  var s = getSettings();
  s.traffic = traffic; s.speed = speed; s.fuelPrice = fuelPrice;
  setSettings(s);
  renderOptimization(optimizeRoutes());
}

(function () {
  var s = getSettings();
  var sel = document.getElementById("optTraffic");
  sel.value = String(s.traffic);
  if (sel.value === "") sel.value = "1";
  document.getElementById("speed").value = s.speed;
  document.getElementById("fuelPrice").value = s.fuelPrice;
  renderOptimization(getRoutes());
})();
