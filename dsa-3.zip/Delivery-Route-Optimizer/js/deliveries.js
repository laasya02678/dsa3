function statusBadge(s) {
  var cls = s === "Delivered" ? "success" : (s === "In Transit" ? "warning" : "");
  return '<span class="badge ' + cls + '">' + esc(s) + "</span>";
}

function renderDeliveries() {
  var list = getDeliveries();
  var body = document.getElementById("deliveryRows");
  if (!list.length) { body.innerHTML = '<tr><td colspan="7">No deliveries yet. Add one above.</td></tr>'; return; }
  body.innerHTML = list.map(function (d) {
    return "<tr><td>" + esc(d.id) + "</td><td>" + esc(d.customer) + "</td><td>" + esc(d.location) +
      "</td><td>" + esc(d.demand) + "</td><td>" + esc(d.window) + "</td><td>" + statusBadge(d.status) +
      '</td><td><button class="btn danger" onclick="deleteDelivery(\'' + esc(d.id) + '\')">Delete</button></td></tr>';
  }).join("");
}

function deleteDelivery(id) {
  if (!confirm("Delete delivery " + id + "?")) return;
  setDeliveries(getDeliveries().filter(function (d) { return d.id !== id; }));
  renderDeliveries();
}

document.getElementById("deliveryForm").addEventListener("submit", function (e) {
  e.preventDefault();
  var customer = document.getElementById("customer").value.trim();
  var locInput = document.getElementById("location").value.trim().toLowerCase();
  var demand = parseInt(document.getElementById("demand").value, 10);
  var win = document.getElementById("window").value.trim();
  var status = document.getElementById("status").value;

  var location = null;
  GRAPH_NODES.forEach(function (n) { if (n !== "Warehouse" && n.toLowerCase() === locInput) location = n; });
  if (!customer) { alert("Please enter a customer name."); return; }
  if (!location) { alert("Unknown location. Use one of: " + GRAPH_NODES.slice(1).join(", ")); return; }
  if (!demand || demand < 1) { alert("Packages must be a whole number of at least 1."); return; }
  if (!/^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}$/.test(win)) { alert("Time window must look like 10:00-12:00"); return; }

  var list = getDeliveries();
  list.push({ id: nextDeliveryId(), customer: customer, location: location, demand: demand, window: win.replace(/\s/g, ""), status: status });
  setDeliveries(list);
  this.reset();
  renderDeliveries();
});

renderDeliveries();
