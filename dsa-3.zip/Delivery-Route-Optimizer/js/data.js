/* Shared data layer: storage, demo data, graph definition, assignment */
var KEYS = {
  deliveries: "dro_deliveries",
  vehicles: "dro_vehicles",
  assignment: "dro_assignment",
  routes: "dro_routes",
  settings: "dro_settings"
};

var GRAPH_NODES = ["Warehouse", "Kukatpally", "Miyapur", "KPHB", "JNTU", "Ameerpet", "Hitech City"];
var GRAPH_EDGES = [
  ["Warehouse", "KPHB", 5], ["Warehouse", "Ameerpet", 9], ["Warehouse", "Kukatpally", 7],
  ["Kukatpally", "KPHB", 3], ["Kukatpally", "Miyapur", 5], ["Kukatpally", "JNTU", 4],
  ["KPHB", "JNTU", 2.5], ["KPHB", "Miyapur", 6], ["KPHB", "Hitech City", 8],
  ["JNTU", "Hitech City", 5], ["Ameerpet", "Hitech City", 7], ["Ameerpet", "KPHB", 6.5],
  ["Miyapur", "Hitech City", 8]
];
var NODE_POS = {
  "Warehouse": [120, 300], "Miyapur": [210, 90], "Kukatpally": [400, 120], "KPHB": [340, 290],
  "JNTU": [560, 210], "Ameerpet": [430, 470], "Hitech City": [760, 340]
};

var DEFAULT_DELIVERIES = [
  { id: "D001", customer: "Ravi Traders", location: "Kukatpally", demand: 12, window: "09:00-11:00", status: "Pending" },
  { id: "D002", customer: "Sri Pharma", location: "Miyapur", demand: 8, window: "10:00-12:00", status: "Pending" },
  { id: "D003", customer: "Anil Electronics", location: "KPHB", demand: 15, window: "11:00-13:00", status: "In Transit" },
  { id: "D004", customer: "Campus Mart", location: "JNTU", demand: 6, window: "12:00-14:00", status: "Pending" },
  { id: "D005", customer: "Metro Foods", location: "Ameerpet", demand: 20, window: "13:00-15:00", status: "Pending" },
  { id: "D006", customer: "Tech Supplies", location: "Hitech City", demand: 10, window: "14:00-16:00", status: "Delivered" }
];
var DEFAULT_VEHICLES = [
  { id: "V001", capacity: 40, efficiency: 12, availability: "Available" },
  { id: "V002", capacity: 30, efficiency: 15, availability: "Available" },
  { id: "V003", capacity: 25, efficiency: 18, availability: "Available" }
];
var DEFAULT_SETTINGS = { traffic: 1, speed: 30, fuelPrice: 105, penalties: {} };


/* ---------- optional backend sync (active only when server.js is running) ----------
   Under Live Server /api/state does not exist, so everything stays in localStorage. */
var SERVER_MODE = false;
(function () {
  try {
    var x = new XMLHttpRequest();
    x.open("GET", "/api/state", false); x.send();
    if (x.status === 200 && /json/.test(x.getResponseHeader("Content-Type") || "")) {
      SERVER_MODE = true;
      var s = JSON.parse(x.responseText);
      if (s && s._v) {
        Object.keys(KEYS).forEach(function (k) {
          var name = KEYS[k];
          if (s[name] !== undefined) localStorage.setItem(name, s[name]); else localStorage.removeItem(name);
        });
      }
    }
  } catch (e) {}
})();
function pushToServer() {
  if (!SERVER_MODE) return;
  try {
    var out = { _v: 1 };
    Object.keys(KEYS).forEach(function (k) { var v = localStorage.getItem(KEYS[k]); if (v !== null) out[KEYS[k]] = v; });
    var x = new XMLHttpRequest();
    x.open("PUT", "/api/state", false);
    x.setRequestHeader("Content-Type", "application/json");
    x.send(JSON.stringify(out));
  } catch (e) {}
}

/* ---------- storage ---------- */
function load(key, fallback) {
  try {
    var v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch (e) { return fallback; }
}
function save(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {} pushToServer(); }
function removeKey(key) { try { localStorage.removeItem(key); } catch (e) {} pushToServer(); }

function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}

/* ---------- formatting ---------- */
function fmtKm(n) { return (Math.round(n * 10) / 10).toFixed(1) + " km"; }
function fmtMin(n) { return Math.round(n) + " min"; }
function fmtL(n) { return (Math.round(n * 100) / 100).toFixed(2) + " L"; }
function fmtMoney(n) { return "₹" + Math.round(n).toLocaleString("en-IN"); }

/* ---------- deliveries / vehicles / settings ---------- */
function getDeliveries() {
  var d = load(KEYS.deliveries, null);
  if (!d) { d = JSON.parse(JSON.stringify(DEFAULT_DELIVERIES)); save(KEYS.deliveries, d); }
  return d;
}
function getVehicles() {
  var v = load(KEYS.vehicles, null);
  if (!v) { v = JSON.parse(JSON.stringify(DEFAULT_VEHICLES)); save(KEYS.vehicles, v); }
  return v;
}
/* Saving deliveries/vehicles invalidates old assignment + route results */
function clearComputed() { removeKey(KEYS.assignment); removeKey(KEYS.routes); }
function setDeliveries(list) { save(KEYS.deliveries, list); clearComputed(); }
function setVehicles(list) { save(KEYS.vehicles, list); clearComputed(); }

function getSettings() {
  var s = load(KEYS.settings, {});
  var out = {};
  for (var k in DEFAULT_SETTINGS) out[k] = (s[k] !== undefined) ? s[k] : DEFAULT_SETTINGS[k];
  return out;
}
function setSettings(s) { save(KEYS.settings, s); }
function getAssignment() { return load(KEYS.assignment, null); }
function getRoutes() { return load(KEYS.routes, []); }

function nextDeliveryId() {
  var max = 0;
  getDeliveries().forEach(function (d) {
    var n = parseInt(String(d.id).replace(/\D/g, ""), 10);
    if (n > max) max = n;
  });
  return "D" + String(max + 1).padStart(3, "0");
}

function resetData() {
  if (!confirm("Reset all deliveries, vehicles, assignment and route data to the demo defaults?")) return;
  Object.keys(KEYS).forEach(function (k) { removeKey(KEYS[k]); });
  location.reload();
}

/* ---------- greedy capacity-based assignment (first-fit decreasing) ---------- */
function runAssignment() {
  var vehicles = getVehicles().filter(function (v) { return v.availability === "Available"; })
    .sort(function (a, b) { return b.capacity - a.capacity; });
  var items = getDeliveries().filter(function (d) { return d.status !== "Delivered"; })
    .sort(function (a, b) { return b.demand - a.demand; });
  var result = {
    vehicles: vehicles.map(function (v) {
      return { vehicleId: v.id, capacity: v.capacity, assigned: 0, remaining: v.capacity, deliveries: [] };
    }),
    unassigned: [],
    ranAt: Date.now()
  };
  items.forEach(function (d) {
    var slot = null;
    for (var i = 0; i < result.vehicles.length; i++) {
      if (result.vehicles[i].remaining >= d.demand) { slot = result.vehicles[i]; break; }
    }
    if (slot) { slot.deliveries.push(d.id); slot.assigned += d.demand; slot.remaining -= d.demand; }
    else result.unassigned.push(d.id);
  });
  save(KEYS.assignment, result);
  removeKey(KEYS.routes); // old routes are stale after re-assigning
  return result;
}
