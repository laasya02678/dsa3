(function () {
  var routes = getRoutes(), del = getDeliveries(), veh = getVehicles(), asg = getAssignment();
  function sum(k) { return routes.reduce(function (a, r) { return a + r[k]; }, 0); }
  document.getElementById("rDistance").textContent = fmtKm(sum("km"));
  document.getElementById("rFuel").textContent = fmtL(sum("fuel"));
  document.getElementById("rCost").textContent = fmtMoney(sum("cost"));
  document.getElementById("rTime").textContent = fmtMin(sum("time"));

  var box = document.getElementById("reportSummary");
  if (!routes.length) {
    box.innerHTML = '<div class="alert info">No optimized routes yet. Run Assignment, then Optimization.</div>';
  } else {
    box.innerHTML = '<div class="table-wrap"><table><thead><tr><th>Vehicle</th><th>Stops</th><th>Route</th><th>Distance</th><th>Time</th><th>Fuel</th><th>Cost</th></tr></thead><tbody>' +
      routes.map(function (r) {
        return "<tr><td>" + esc(r.vehicleId) + "</td><td>" + r.stops.length + "</td><td>" + r.path.map(esc).join(" → ") + "</td><td>" +
          fmtKm(r.km) + "</td><td>" + fmtMin(r.time) + "</td><td>" + fmtL(r.fuel) + "</td><td>" + fmtMoney(r.cost) + "</td></tr>";
      }).join("") + "</tbody></table></div>";
  }

  function cnt(s) { return del.filter(function (d) { return d.status === s; }).length; }
  var cap = asg ? asg.vehicles.reduce(function (a, s) { return a + s.capacity; }, 0) : 0;
  var used = asg ? asg.vehicles.reduce(function (a, s) { return a + s.assigned; }, 0) : 0;
  var dj = routes.reduce(function (a, r) { return a + r.dijkstraKm; }, 0);
  var gr = routes.reduce(function (a, r) { return a + r.greedyKm; }, 0);
  var mx = Math.max(dj, gr);
  var metrics = [
    ["Total Deliveries", del.length], ["Delivered", cnt("Delivered")], ["Pending", cnt("Pending")],
    ["In Transit", cnt("In Transit")], ["Vehicles", veh.length],
    ["Available Vehicles", veh.filter(function (v) { return v.availability === "Available"; }).length],
    ["Capacity Used", cap ? (used / cap * 100).toFixed(1) + "%" : "N/A"],
    ["Unassigned Deliveries", asg ? asg.unassigned.length : "N/A"],
    ["Distance Saved by Best Method", mx ? ((mx - Math.min(dj, gr)) / mx * 100).toFixed(1) + "%" : "N/A"]
  ];
  document.getElementById("metricGrid").innerHTML = metrics.map(function (m) {
    return '<div class="metric">' + esc(m[0]) + "<strong>" + esc(m[1]) + "</strong></div>";
  }).join("");
})();
