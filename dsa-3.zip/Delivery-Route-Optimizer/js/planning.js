function buildPlan() {
  var traffic = parseFloat(document.getElementById("traffic").value) || 1;
  var s = getSettings();
  s.traffic = traffic;
  setSettings(s);

  document.getElementById("nodes").innerHTML = GRAPH_NODES.map(function (n) {
    return '<span class="chip">' + esc(n) + "</span>";
  }).join("");

  var g = buildGraph({ traffic: traffic });
  var all = {};
  GRAPH_NODES.forEach(function (n) { all[n] = dijkstra(g, n); });

  var html = "<thead><tr><th>From \\ To</th>" + GRAPH_NODES.map(function (n) { return "<th>" + esc(n) + "</th>"; }).join("") + "</tr></thead><tbody>";
  GRAPH_NODES.forEach(function (a) {
    html += "<tr><th>" + esc(a) + "</th>" + GRAPH_NODES.map(function (b) {
      return "<td>" + (Math.round(all[a].dist[b] * 10) / 10) + "</td>";
    }).join("") + "</tr>";
  });
  document.getElementById("matrix").innerHTML = html + "</tbody>";

  var from = all["Warehouse"];
  var rows = GRAPH_NODES.filter(function (n) { return n !== "Warehouse"; }).map(function (n) {
    var p = pathTo(from, "Warehouse", n);
    return "<tr><td>" + esc(n) + "</td><td>" + (p ? p.map(esc).join(" → ") : "No path") + "</td><td>" +
      (p ? (Math.round(from.dist[n] * 10) / 10) + " km" : "-") + "</td></tr>";
  }).join("");
  document.getElementById("shortestPaths").innerHTML =
    '<div class="table-wrap"><table><thead><tr><th>Destination</th><th>Shortest path</th><th>Distance' +
    (traffic > 1 ? " (traffic-adjusted)" : "") + "</th></tr></thead><tbody>" + rows + "</tbody></table></div>";
}

(function () {
  var s = getSettings();
  var sel = document.getElementById("traffic");
  sel.value = String(s.traffic);
  if (sel.value === "") sel.value = "1";
  buildPlan();
})();
