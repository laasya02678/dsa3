var COLORS = ["#2563eb", "#15803d", "#c2410c", "#7c3aed"];

function prep(id) {
  var c = document.getElementById(id);
  c.style.width = "100%";
  var w = c.clientWidth || 600, h = 320, dpr = window.devicePixelRatio || 1;
  c.width = Math.round(w * dpr); c.height = Math.round(h * dpr);
  var ctx = c.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx: ctx, w: w, h: h };
}
function empty(p, msg) {
  p.ctx.fillStyle = "#64748b"; p.ctx.font = "14px Arial"; p.ctx.textAlign = "center";
  p.ctx.fillText(msg, p.w / 2, p.h / 2);
}

function bars(id, labels, series, unit, fixedMax) {
  var p = prep(id), ctx = p.ctx;
  if (!labels.length) { empty(p, "No data yet. Run Assignment and Optimization first."); return; }
  var L = 55, R = 15, T = series.length > 1 ? 34 : 20, B = 36;
  var max = fixedMax || 0;
  if (!fixedMax) series.forEach(function (s) { s.values.forEach(function (v) { if (v > max) max = v; }); });
  max = max || 1;
  var plotH = p.h - T - B, plotW = p.w - L - R;
  ctx.font = "12px Arial"; ctx.textAlign = "right"; ctx.strokeStyle = "#e2e8f0"; ctx.fillStyle = "#64748b";
  for (var i = 0; i <= 4; i++) {
    var y = T + plotH - plotH * i / 4;
    ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(p.w - R, y); ctx.stroke();
    ctx.fillText((Math.round(max * i / 4 * 10) / 10) + "", L - 6, y + 4);
  }
  var gw = plotW / labels.length, bw = Math.min(46, gw * 0.7 / series.length);
  labels.forEach(function (lab, li) {
    var gx = L + gw * li + gw / 2 - bw * series.length / 2;
    series.forEach(function (s, si) {
      var v = s.values[li], bh = plotH * v / max, x = gx + si * bw, y = T + plotH - bh;
      ctx.fillStyle = s.color; ctx.fillRect(x, y, bw - 2, bh);
      ctx.fillStyle = "#172033"; ctx.textAlign = "center"; ctx.font = "11px Arial";
      ctx.fillText((Math.round(v * 10) / 10) + unit, x + (bw - 2) / 2, y - 4);
    });
    ctx.fillStyle = "#334155"; ctx.font = "12px Arial"; ctx.textAlign = "center";
    ctx.fillText(lab, L + gw * li + gw / 2, p.h - 14);
  });
  if (series.length > 1) {
    var x = L;
    series.forEach(function (s) {
      ctx.fillStyle = s.color; ctx.fillRect(x, 10, 12, 12);
      ctx.fillStyle = "#334155"; ctx.textAlign = "left"; ctx.font = "12px Arial";
      ctx.fillText(s.name, x + 18, 21); x += ctx.measureText(s.name).width + 40;
    });
  }
}

function pie() {
  var p = prep("statusChart"), ctx = p.ctx, del = getDeliveries();
  var data = [["Pending", "#f59e0b"], ["In Transit", "#2563eb"], ["Delivered", "#15803d"]].map(function (x) {
    return { name: x[0], color: x[1], n: del.filter(function (d) { return d.status === x[0]; }).length };
  });
  var total = data.reduce(function (a, d) { return a + d.n; }, 0);
  if (!total) { empty(p, "No deliveries yet."); return; }
  var cx = p.w * 0.35, cy = p.h / 2, r = Math.min(p.h / 2 - 20, p.w * 0.3), a0 = -Math.PI / 2;
  data.forEach(function (d) {
    if (!d.n) return;
    var a1 = a0 + d.n / total * Math.PI * 2;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, a0, a1); ctx.closePath();
    ctx.fillStyle = d.color; ctx.fill(); a0 = a1;
  });
  ctx.beginPath(); ctx.arc(cx, cy, r * 0.5, 0, Math.PI * 2); ctx.fillStyle = "#fff"; ctx.fill();
  ctx.fillStyle = "#172033"; ctx.textAlign = "center"; ctx.font = "bold 22px Arial"; ctx.fillText(total, cx, cy + 4);
  ctx.font = "11px Arial"; ctx.fillStyle = "#64748b"; ctx.fillText("deliveries", cx, cy + 20);
  var y = p.h / 2 - 40;
  data.forEach(function (d) {
    ctx.fillStyle = d.color; ctx.fillRect(p.w * 0.65, y, 14, 14);
    ctx.fillStyle = "#334155"; ctx.textAlign = "left"; ctx.font = "14px Arial";
    ctx.fillText(d.name + ": " + d.n, p.w * 0.65 + 22, y + 12); y += 30;
  });
}

function drawAll() {
  var routes = getRoutes(), asg = getAssignment();
  var labels = routes.map(function (r) { return r.vehicleId; });
  bars("distanceChart", labels, [{ name: "Distance", color: COLORS[0], values: routes.map(function (r) { return r.km; }) }], " km");
  bars("costChart", labels, [{ name: "Cost", color: COLORS[1], values: routes.map(function (r) { return r.cost; }) }], "");
  pie();
  var slots = asg ? asg.vehicles : [];
  bars("utilizationChart", slots.map(function (s) { return s.vehicleId; }),
    [{ name: "Utilization", color: COLORS[3], values: slots.map(function (s) { return s.capacity ? s.assigned / s.capacity * 100 : 0; }) }], "%", 100);
  bars("algorithmChart", labels, [
    { name: "Dijkstra (separate trips)", color: COLORS[0], values: routes.map(function (r) { return r.dijkstraKm; }) },
    { name: "Greedy sequence", color: COLORS[2], values: routes.map(function (r) { return r.greedyKm; }) }
  ], " km");
}

drawAll();
window.addEventListener("resize", drawAll);
