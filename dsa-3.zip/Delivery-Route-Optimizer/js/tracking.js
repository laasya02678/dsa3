function statusBadge(s) {
  var cls = s === "Delivered" ? "success" : (s === "In Transit" ? "warning" : "");
  return '<span class="badge ' + cls + '">' + esc(s) + "</span>";
}

function renderTracking() {
  var list = getDeliveries();
  var body = document.getElementById("trackingRows");
  if (!list.length) { body.innerHTML = '<tr><td colspan="5">No deliveries to track.</td></tr>'; return; }
  body.innerHTML = list.map(function (d) {
    var opts = ["Pending", "In Transit", "Delivered"].map(function (s) {
      return '<option' + (s === d.status ? " selected" : "") + ">" + s + "</option>";
    }).join("");
    return "<tr><td>" + esc(d.id) + "</td><td>" + esc(d.customer) + "</td><td>" + esc(d.location) + "</td><td>" + statusBadge(d.status) +
      '</td><td><select onchange="updateStatus(\'' + esc(d.id) + '\', this.value)">' + opts + "</select></td></tr>";
  }).join("");
}

function updateStatus(id, status) {
  var list = getDeliveries();
  list.forEach(function (d) { if (d.id === id) d.status = status; });
  setDeliveries(list); // also clears stale assignment / route results
  renderTracking();
}

renderTracking();
