/* Shared UI helpers: current user + logout */
function logout() {
  try { localStorage.removeItem("dro_user"); } catch (e) {}
}
(function () {
  var el = document.getElementById("currentUser");
  if (el) {
    var u = null;
    try { u = localStorage.getItem("dro_user"); } catch (e) {}
    el.textContent = u || "Demo User";
  }
})();
